(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,98903,94002,21928,e=>{"use strict";var t=e.i(30353);e.s(["f",()=>t.F],98903);var r=e.i(43476),n=e.i(75056),t=t,i=e.i(38408),o=e.i(71645),a=e.i(16312),s=e.i(85115),t=t,l=e.i(8560),u=e.i(90072),m=e.i(31935);let c="#d6aa48",f="#f3d98e",d="#070709";function p({intensity:e=1}){let t=(0,i.f)(e=>e.gl),r=(0,i.f)(e=>e.scene);return(0,o.useEffect)(()=>{let n=new l.c(t),i=n.fromScene(new m.f,.04).texture;return r.environment=i,r.environmentIntensity=e,()=>{r.environment=null,i.dispose(),n.dispose()}},[t,r,e]),null}function v(){let e=(0,i.f)(e=>e.setDpr),r=(0,o.useRef)({time:0,frames:0,skip:30,stage:0});return(0,t.F)((t,n)=>{let i=r.current;if(i.stage>1)return;if(i.skip>0)return void i.skip--;if(i.time+=Math.min(n,.25),i.frames++,i.time<2)return;let o=i.frames/i.time;Object.assign(i,{time:0,frames:0,skip:10}),o>=45?i.stage=2:0===i.stage?(e(1),i.stage=1):((0,a.h)(),i.stage=2)}),null}function h({fps:e}){let t=(0,i.f)(e=>e.invalidate);return(0,o.useEffect)(()=>{let r=window.setInterval(()=>t(),1e3/e);return()=>window.clearInterval(r)},[t,e]),null}e.s(["l",0,c,"T",0,f,"x",0,function({count:e=400,radius:n=7,height:a=10,size:l=22}){let m=(0,i.f)(e=>e.viewport.dpr),c=(0,s.f)()?Math.round(e/2):e,{geometry:d,material:p}=(0,o.useMemo)(()=>{let e=new Float32Array(3*c),t=new Float32Array(c);for(let r=0;r<c;r++){let i=Math.sqrt(Math.random())*n,o=Math.random()*Math.PI*2;e[3*r]=Math.cos(o)*i,e[3*r+1]=Math.random()*a,e[3*r+2]=Math.sin(o)*i,t[r]=Math.random()}let r=new u.ld;return r.setAttribute("position",new u.f5(e,3)),r.setAttribute("aSeed",new u.f5(t,1)),{geometry:r,material:new u.Zg({transparent:!0,depthWrite:!1,blending:u.tq,uniforms:{uTime:{value:0},uSize:{value:l},uDpr:{value:1},uHeight:{value:a},uColor:{value:new u.Es(f)}},vertexShader:`
        attribute float aSeed;
        uniform float uTime, uSize, uDpr, uHeight;
        varying float vAlpha;
        void main() {
          vec3 p = position;
          p.y = mod(p.y + uTime * (0.12 + aSeed * 0.3), uHeight);
          p.x += sin(uTime * 0.4 + aSeed * 20.0) * 0.25;
          p.z += cos(uTime * 0.3 + aSeed * 12.0) * 0.25;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = uSize * uDpr * (0.35 + aSeed) / -mv.z;
          vAlpha = smoothstep(0.0, 1.2, p.y) * (1.0 - smoothstep(uHeight * 0.7, uHeight, p.y)) * (0.35 + aSeed * 0.65);
        }`,fragmentShader:`
        uniform vec3 uColor;
        varying float vAlpha;
        void main() {
          float d = length(gl_PointCoord - 0.5);
          if (d > 0.5) discard;
          gl_FragColor = vec4(uColor, smoothstep(0.5, 0.0, d) * vAlpha);
        }`})}},[c,n,a,l]);return(0,o.useEffect)(()=>()=>(d.dispose(),p.dispose()),[d,p]),(0,t.F)((e,t)=>{p.uniforms.uTime.value+=t,p.uniforms.uDpr.value=m}),(0,r.jsx)("points",{geometry:d,material:p})},"H",0,p,"i",0,function({size:e=40,y:n=0,pulse:i=!0}){let a=(0,o.useMemo)(()=>new u.Zg({transparent:!0,depthWrite:!1,uniforms:{uTime:{value:0},uColor:{value:new u.Es(c)},uPulse:{value:+!!i}},vertexShader:`
          varying vec2 vPos;
          void main() {
            vPos = position.xy;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }`,fragmentShader:`
          uniform float uTime;
          uniform vec3 uColor;
          uniform float uPulse;
          varying vec2 vPos;
          float grid(vec2 p, float s) {
            vec2 q = p / s;
            vec2 g = abs(fract(q - 0.5) - 0.5) / fwidth(q);
            return 1.0 - min(min(g.x, g.y), 1.0);
          }
          void main() {
            float d = length(vPos);
            float fade = 1.0 - smoothstep(1.5, 13.0, d);
            float g = grid(vPos, 0.5) * 0.35 + grid(vPos, 2.0) * 0.75;
            float r = mod(uTime * 1.6, 18.0);
            float ring = smoothstep(0.35, 0.0, abs(d - r)) * (1.0 - r / 18.0) * uPulse;
            float a = (g * 0.32 + ring * 0.55) * fade;
            gl_FragColor = vec4(uColor, a);
          }`}),[i]);return(0,t.F)((e,t)=>{a.uniforms.uTime.value+=t}),(0,r.jsx)("mesh",{"rotation-x":-Math.PI/2,"position-y":n,material:a,renderOrder:-1,children:(0,r.jsx)("planeGeometry",{args:[e,e]})})},"s",0,d,"B",0,function(){return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)("ambientLight",{intensity:.25}),(0,r.jsx)("directionalLight",{position:[5,9,6],intensity:1.6,color:"#fff3dc"}),(0,r.jsx)("directionalLight",{position:[-6,5,-7],intensity:1.1,color:f}),(0,r.jsx)("pointLight",{position:[-3,2,4],intensity:18,distance:14,color:c})]})},"o",0,e=>{let t=Math.min(Math.max(e,0),1);return 1+2.4*Math.pow(t-1,3)+1.4*Math.pow(t-1,2)},"z",0,e=>1-Math.pow(1-Math.min(Math.max(e,0),1),3),"g",0,(e=.75)=>new u.NQ({color:f,transparent:!0,opacity:e,depthWrite:!1}),"y",0,()=>new u.aV({color:c,metalness:1,roughness:.26,envMapIntensity:1.25}),"n",0,function(e=.05){let r=(0,o.useRef)(new u.wq);return(0,t.F)(t=>{r.current.lerp(t.pointer,e)}),r}],94002),e.s(["f",0,function({children:e,active:t,reduced:i,onReady:o,camera:a={position:[0,2,10],fov:35},fog:l,env:u=1}){let m=(0,s.f)(),c=t&&!i;return(0,r.jsxs)(n.f,{dpr:m?1:[1,1.5],gl:{antialias:!m,alpha:!0,powerPreference:"high-performance"},camera:{fov:a.fov??35,near:.1,far:100,position:a.position},frameloop:t?i||m?"demand":"always":"never",onCreated:({gl:e})=>{e.setClearColor(d,0),requestAnimationFrame(()=>o?.())},style:{width:"100%",height:"100%"},children:[c&&m?(0,r.jsx)(h,{fps:30}):null,c&&!m?(0,r.jsx)(v,{}):null,l?(0,r.jsx)("fog",{attach:"fog",args:[d,l[0],l[1]]}):null,(0,r.jsx)(p,{intensity:u}),e]})}],21928)},8251,e=>{"use strict";var t=e.i(43476),r=e.i(52239),n=e.i(98903),i=e.i(38408),o=e.i(71645),a=e.i(90072),s=e.i(21928),l=e.i(94002);let u=2,m=Math.PI/180,c=[{name:"Dubai",lat:25.2048,lng:55.2708,hq:!0},{name:"Philippines",lat:14.5995,lng:120.9842},{name:"India",lat:19.076,lng:72.8777},{name:"Sri Lanka",lat:6.9271,lng:79.8612}],f=(e,t,r=u)=>{let n=(90-e)*m,i=(t+180)*m;return new a.cE(-r*Math.sin(n)*Math.cos(i),r*Math.cos(n),r*Math.sin(n)*Math.sin(i))};function d(){let[e,s]=(0,o.useState)(null),m=(0,i.f)(e=>e.viewport.dpr);(0,o.useEffect)(()=>{let e=!0;return fetch((0,r.f)("/data/globe-land.json")).then(e=>e.json()).then(t=>e&&s(t)).catch(()=>{}),()=>{e=!1}},[]);let c=(0,o.useMemo)(()=>{if(!e)return null;let t=e.length/2,r=new Float32Array(3*t);for(let n=0;n<t;n++){let t=f(e[2*n]/10,e[2*n+1]/10,u);r.set([t.x,t.y,t.z],3*n)}let n=new a.ld;n.setAttribute("position",new a.f5(r,3));let i=new a.Zg({transparent:!0,depthWrite:!1,uniforms:{uColor:{value:new a.Es(l.T)},uDpr:{value:1}},vertexShader:`
        uniform float uDpr;
        varying float vFacing;
        void main() {
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vec3 n = normalize(normalMatrix * normalize(position));
          vFacing = dot(n, normalize(-mv.xyz));
          gl_Position = projectionMatrix * mv;
          gl_PointSize = 5.0 * uDpr * (6.0 / -mv.z);
        }`,fragmentShader:`
        uniform vec3 uColor;
        varying float vFacing;
        void main() {
          float d = length(gl_PointCoord - 0.5);
          if (d > 0.5) discard;
          float a = smoothstep(0.5, 0.15, d) * mix(0.08, 0.95, smoothstep(-0.1, 0.6, vFacing));
          gl_FragColor = vec4(uColor, a);
        }`});return new a.sy(n,i)},[e]);return(0,o.useEffect)(()=>()=>{c&&(c.geometry.dispose(),c.material.dispose())},[c]),(0,n.f)(()=>{c&&(c.material.uniforms.uDpr.value=m)}),c?(0,t.jsx)("primitive",{object:c}):null}function p(){let e=(0,o.useMemo)(()=>new a.Zg({transparent:!0,depthWrite:!1,side:a.tw,blending:a.tq,uniforms:{uColor:{value:new a.Es(l.l)}},vertexShader:"varying vec3 vN; varying vec3 vV; void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }",fragmentShader:"uniform vec3 uColor; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0 - abs(dot(vN, vV)), 3.0); gl_FragColor = vec4(uColor, f * 0.6); }"}),[]);return(0,t.jsx)("mesh",{material:e,scale:1.18,children:(0,t.jsx)("sphereGeometry",{args:[u,64,64]})})}function v({from:e,to:r,delay:i}){let s=(0,o.useMemo)(()=>{let t=e.clone().add(r).multiplyScalar(.5),n=1+.22*e.distanceTo(r),i=new a.pN(e,t.normalize().multiplyScalar(u*n),r).getPoints(80),o=new a.ld().setFromPoints(i);o.setAttribute("aT",new a.f5(new Float32Array(i.map((e,t)=>t/(i.length-1))),1));let s=new a.Zg({transparent:!0,depthWrite:!1,blending:a.tq,uniforms:{uTime:{value:0},uColor:{value:new a.Es(l.T)}},vertexShader:"attribute float aT; varying float vT; void main(){ vT = aT; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`uniform float uTime; uniform vec3 uColor; varying float vT;
        void main(){
          float grow = smoothstep(vT - 0.02, vT, uTime * 0.6);
          float dash = smoothstep(0.35, 0.5, fract(vT * 14.0 - uTime * 1.2));
          float head = smoothstep(0.12, 0.0, abs(vT - fract(uTime * 0.35)));
          gl_FragColor = vec4(uColor, grow * (0.25 + dash * 0.45 + head));
        }`});return new a.DL(o,s)},[e,r]);return(0,o.useEffect)(()=>()=>(s.geometry.dispose(),s.material.dispose()),[s]),(0,n.f)(e=>{s.material.uniforms.uTime.value=Math.max(0,e.clock.elapsedTime-i)}),(0,t.jsx)("primitive",{object:s})}function h({pos:e,hq:r,delay:i}){let s=(0,o.useRef)(null),u=(0,o.useMemo)(()=>new a.as().setFromUnitVectors(new a.cE(0,0,1),e.clone().normalize()),[e]);(0,n.f)(e=>{let t=(.8*e.clock.elapsedTime+i)%1;s.current&&(s.current.scale.setScalar(.4+1.8*t),s.current.material.opacity=(1-t)*.9)});let m=e.clone().multiplyScalar(r?1.14:1.09);return(0,t.jsxs)("group",{children:[(0,t.jsxs)("mesh",{position:e.clone().multiplyScalar(1.004),quaternion:u,ref:s,children:[(0,t.jsx)("ringGeometry",{args:[.07,.09,40]}),(0,t.jsx)("meshBasicMaterial",{color:r?"#ff6b7d":l.T,transparent:!0,side:a.Vs,depthWrite:!1})]}),(0,t.jsxs)("mesh",{position:e.clone().lerp(m,.5),quaternion:new a.as().setFromUnitVectors(new a.cE(0,1,0),e.clone().normalize()),children:[(0,t.jsx)("cylinderGeometry",{args:[.006,.006,e.distanceTo(m),6]}),(0,t.jsx)("meshBasicMaterial",{color:l.T})]}),(0,t.jsxs)("mesh",{position:m,children:[(0,t.jsx)("sphereGeometry",{args:[r?.05:.035,16,16]}),(0,t.jsx)("meshBasicMaterial",{color:r?"#ff6b7d":"#fff1c4"})]})]})}function g(){let e=(0,o.useRef)(null),r=(0,o.useRef)({down:!1,x:0,offset:0,vel:0}),a=(0,i.f)(e=>e.gl),s=(0,i.f)(e=>e.size),g=(0,o.useMemo)(()=>c.map(e=>({...e,pos:f(e.lat,e.lng,u)})),[]),x=g[0].pos,w=-175*m;return(0,o.useEffect)(()=>{let e=a.domElement;e.style.touchAction="pan-y",e.style.cursor="grab";let t=t=>{r.current.down=!0,r.current.x=t.clientX,e.style.cursor="grabbing"},n=e=>{if(!r.current.down)return;let t=e.clientX-r.current.x;r.current.x=e.clientX,r.current.vel=t/s.width*4,r.current.offset+=r.current.vel},i=()=>{r.current.down=!1,e.style.cursor="grab"};return e.addEventListener("pointerdown",t),window.addEventListener("pointermove",n),window.addEventListener("pointerup",i),()=>{e.removeEventListener("pointerdown",t),window.removeEventListener("pointermove",n),window.removeEventListener("pointerup",i)}},[a,s.width]),(0,n.f)((t,n)=>{let i=r.current;i.down||(i.vel*=.94,i.offset+=i.vel,i.offset*=1-Math.min(.35*n,1));let o=t.clock.elapsedTime;e.current&&(e.current.rotation.y=w+.35*Math.sin(.25*o)+i.offset,e.current.rotation.x=.32+.06*t.pointer.y)}),(0,t.jsxs)("group",{ref:e,children:[(0,t.jsxs)("mesh",{children:[(0,t.jsx)("sphereGeometry",{args:[.995*u,64,64]}),(0,t.jsx)("meshStandardMaterial",{color:"#09090c",metalness:.6,roughness:.55,transparent:!0,opacity:.92})]}),(0,t.jsxs)("mesh",{children:[(0,t.jsx)("sphereGeometry",{args:[1.001*u,36,18]}),(0,t.jsx)("meshBasicMaterial",{color:l.l,wireframe:!0,transparent:!0,opacity:.05})]}),(0,t.jsx)(d,{}),(0,t.jsx)(p,{}),g.map((e,r)=>(0,t.jsx)(h,{pos:e.pos,hq:e.hq,delay:.25*r},e.name)),g.slice(1).map((e,r)=>(0,t.jsx)(v,{from:x,to:e.pos,delay:.6+.5*r},e.name))]})}e.s(["OFFICES",0,c,"default",0,function({active:e,reduced:r,onReady:n}){return(0,t.jsxs)(s.f,{active:e,reduced:r,onReady:n,camera:{position:[0,0,8.2],fov:36},env:.6,children:[(0,t.jsx)("ambientLight",{intensity:.4}),(0,t.jsx)("directionalLight",{position:[4,3,5],intensity:1.2,color:"#fff3dc"}),(0,t.jsx)(g,{}),(0,t.jsx)("group",{"position-y":-3,children:(0,t.jsx)(l.x,{count:140,radius:4.5,height:6,size:16})})]})}])},43528,function(e){e.n(e.i(8251))}]);