(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,98903,94002,21928,e=>{"use strict";var t=e.i(30353);e.s(["f",()=>t.F],98903);var r=e.i(43476),n=e.i(75056),t=t,i=e.i(38408),o=e.i(71645),a=e.i(16312),s=e.i(85115),t=t,l=e.i(8560),u=e.i(90072),c=e.i(31935);let f="#d6aa48",m="#f3d98e",d="#070709";function p({intensity:e=1}){let t=(0,i.f)(e=>e.gl),r=(0,i.f)(e=>e.scene);return(0,o.useEffect)(()=>{let n=new l.c(t),i=n.fromScene(new c.f,.04).texture;return r.environment=i,r.environmentIntensity=e,()=>{r.environment=null,i.dispose(),n.dispose()}},[t,r,e]),null}function h(){let e=(0,i.f)(e=>e.setDpr),r=(0,o.useRef)({time:0,frames:0,skip:30,stage:0});return(0,t.F)((t,n)=>{let i=r.current;if(i.stage>1)return;if(i.skip>0)return void i.skip--;if(i.time+=Math.min(n,.25),i.frames++,i.time<2)return;let o=i.frames/i.time;Object.assign(i,{time:0,frames:0,skip:10}),o>=45?i.stage=2:0===i.stage?(e(1),i.stage=1):((0,a.h)(),i.stage=2)}),null}function v({fps:e}){let t=(0,i.f)(e=>e.invalidate);return(0,o.useEffect)(()=>{let r=window.setInterval(()=>t(),1e3/e);return()=>window.clearInterval(r)},[t,e]),null}e.s(["l",0,f,"T",0,m,"x",0,function({count:e=400,radius:n=7,height:a=10,size:l=22}){let c=(0,i.f)(e=>e.viewport.dpr),f=(0,s.f)()?Math.round(e/2):e,{geometry:d,material:p}=(0,o.useMemo)(()=>{let e=new Float32Array(3*f),t=new Float32Array(f);for(let r=0;r<f;r++){let i=Math.sqrt(Math.random())*n,o=Math.random()*Math.PI*2;e[3*r]=Math.cos(o)*i,e[3*r+1]=Math.random()*a,e[3*r+2]=Math.sin(o)*i,t[r]=Math.random()}let r=new u.ld;return r.setAttribute("position",new u.f5(e,3)),r.setAttribute("aSeed",new u.f5(t,1)),{geometry:r,material:new u.Zg({transparent:!0,depthWrite:!1,blending:u.tq,uniforms:{uTime:{value:0},uSize:{value:l},uDpr:{value:1},uHeight:{value:a},uColor:{value:new u.Es(m)}},vertexShader:`
        attribute float aSeed;
        uniform float uTime, uSize, uDpr, uHeight;
        varying float vAlpha;
        void main() {
          vec3 p = position;
          p.y = mod(p.y + uTime * (0.12 + aSeed * 0.3), uHeight);
          p.x += sin(uTime * 0.4 + aSeed * 20.0) * 0.25;
          p.z += cos(uTime * 0.3 + aSeed * 12.0) * 0.25;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = uSize * uDpr * (0.35 + aSeed) / -mv.z;
          vAlpha = smoothstep(0.0, 1.2, p.y) * (1.0 - smoothstep(uHeight * 0.7, uHeight, p.y)) * (0.35 + aSeed * 0.65);
        }`,fragmentShader:`
        uniform vec3 uColor;
        varying float vAlpha;
        void main() {
          float d = length(gl_PointCoord - 0.5);
          if (d > 0.5) discard;
          gl_FragColor = vec4(uColor, smoothstep(0.5, 0.0, d) * vAlpha);
        }`})}},[f,n,a,l]);return(0,o.useEffect)(()=>()=>(d.dispose(),p.dispose()),[d,p]),(0,t.F)((e,t)=>{p.uniforms.uTime.value+=t,p.uniforms.uDpr.value=c}),(0,r.jsx)("points",{geometry:d,material:p})},"H",0,p,"i",0,function({size:e=40,y:n=0,pulse:i=!0}){let a=(0,o.useMemo)(()=>new u.Zg({transparent:!0,depthWrite:!1,uniforms:{uTime:{value:0},uColor:{value:new u.Es(f)},uPulse:{value:+!!i}},vertexShader:`
          varying vec2 vPos;
          void main() {
            vPos = position.xy;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }`,fragmentShader:`
          uniform float uTime;
          uniform vec3 uColor;
          uniform float uPulse;
          varying vec2 vPos;
          float grid(vec2 p, float s) {
            vec2 q = p / s;
            vec2 g = abs(fract(q - 0.5) - 0.5) / fwidth(q);
            return 1.0 - min(min(g.x, g.y), 1.0);
          }
          void main() {
            float d = length(vPos);
            float fade = 1.0 - smoothstep(1.5, 13.0, d);
            float g = grid(vPos, 0.5) * 0.35 + grid(vPos, 2.0) * 0.75;
            float r = mod(uTime * 1.6, 18.0);
            float ring = smoothstep(0.35, 0.0, abs(d - r)) * (1.0 - r / 18.0) * uPulse;
            float a = (g * 0.32 + ring * 0.55) * fade;
            gl_FragColor = vec4(uColor, a);
          }`}),[i]);return(0,t.F)((e,t)=>{a.uniforms.uTime.value+=t}),(0,r.jsx)("mesh",{"rotation-x":-Math.PI/2,"position-y":n,material:a,renderOrder:-1,children:(0,r.jsx)("planeGeometry",{args:[e,e]})})},"s",0,d,"B",0,function(){return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)("ambientLight",{intensity:.25}),(0,r.jsx)("directionalLight",{position:[5,9,6],intensity:1.6,color:"#fff3dc"}),(0,r.jsx)("directionalLight",{position:[-6,5,-7],intensity:1.1,color:m}),(0,r.jsx)("pointLight",{position:[-3,2,4],intensity:18,distance:14,color:f})]})},"o",0,e=>{let t=Math.min(Math.max(e,0),1);return 1+2.4*Math.pow(t-1,3)+1.4*Math.pow(t-1,2)},"z",0,e=>1-Math.pow(1-Math.min(Math.max(e,0),1),3),"g",0,(e=.75)=>new u.NQ({color:m,transparent:!0,opacity:e,depthWrite:!1}),"y",0,()=>new u.aV({color:f,metalness:1,roughness:.26,envMapIntensity:1.25}),"n",0,function(e=.05){let r=(0,o.useRef)(new u.wq);return(0,t.F)(t=>{r.current.lerp(t.pointer,e)}),r}],94002),e.s(["f",0,function({children:e,active:t,reduced:i,onReady:o,camera:a={position:[0,2,10],fov:35},fog:l,env:u=1}){let c=(0,s.f)(),f=t&&!i;return(0,r.jsxs)(n.f,{dpr:c?1:[1,1.5],gl:{antialias:!c,alpha:!0,powerPreference:"high-performance"},camera:{fov:a.fov??35,near:.1,far:100,position:a.position},frameloop:t?i||c?"demand":"always":"never",onCreated:({gl:e})=>{e.setClearColor(d,0),requestAnimationFrame(()=>o?.())},style:{width:"100%",height:"100%"},children:[f&&c?(0,r.jsx)(v,{fps:30}):null,f&&!c?(0,r.jsx)(h,{}):null,l?(0,r.jsx)("fog",{attach:"fog",args:[d,l[0],l[1]]}):null,(0,r.jsx)(p,{intensity:u}),e]})}],21928)},22903,e=>{"use strict";var t=e.i(43476),r=e.i(98903),n=e.i(71645),i=e.i(90072),o=e.i(21928),a=e.i(94002);function s(){let e=(0,n.useRef)(null),o=(0,n.useRef)(null),s=(0,a.n)(.05),l=(0,n.useRef)(null),{geo:u,mat:c,wire:f}=(0,n.useMemo)(()=>{let e=new i.eL(1.25,.2,420,40,3,4);return{geo:e,mat:new i.aV({color:a.l,metalness:1,roughness:.18,envMapIntensity:1.6}),wire:new i.p$({color:a.T,wireframe:!0,transparent:!0,opacity:.06})}},[]);return(0,n.useEffect)(()=>()=>(u.dispose(),c.dispose(),f.dispose()),[u,c,f]),(0,r.f)(t=>{let r=t.clock.elapsedTime;null===l.current&&(l.current=r);let n=(0,a.z)((r-l.current)/2.2);e.current&&(e.current.scale.setScalar(.6+.4*n),e.current.rotation.set(.5+-.25*s.current.y,.25*r+.5*s.current.x,Math.PI/4+(1-n)*1.5)),o.current&&(o.current.rotation.z=-(.15*r))}),(0,t.jsxs)("group",{ref:e,children:[(0,t.jsx)("mesh",{geometry:u,material:c}),(0,t.jsx)("mesh",{ref:o,scale:1.35,material:f,children:(0,t.jsx)("icosahedronGeometry",{args:[1.4,2]})})]})}function l(){let e=(0,n.useRef)(null);return(0,r.f)(t=>{e.current&&e.current.children.forEach((e,r)=>{e.rotation.x=Math.PI/2+.3*Math.sin(.3*t.clock.elapsedTime+r),e.rotation.y=t.clock.elapsedTime*(.1+.05*r)})}),(0,t.jsx)("group",{ref:e,children:[2.3,2.75,3.2].map((e,r)=>(0,t.jsxs)("mesh",{children:[(0,t.jsx)("torusGeometry",{args:[e,.006,6,200]}),(0,t.jsx)("meshBasicMaterial",{color:a.T,transparent:!0,opacity:.4-.1*r})]},e))})}e.s(["default",0,function({active:e,reduced:r,onReady:n}){return(0,t.jsxs)(o.f,{active:e,reduced:r,onReady:n,camera:{position:[0,0,8.5],fov:38},env:1.1,children:[(0,t.jsx)(a.B,{}),(0,t.jsx)(s,{}),(0,t.jsx)(l,{}),(0,t.jsx)("group",{"position-y":-3.5,children:(0,t.jsx)(a.x,{count:160,radius:4,height:7,size:18})})]})}])},75505,function(e){e.n(e.i(22903))}]);